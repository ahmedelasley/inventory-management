
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'Administrator','admin@gmail.com',NULL,'$2y$12$9h9vm0NMtxlZl5IKrjY3duMi.leGGem69Py/ZWxHMOHfUeGxB/Bpu','JUQNeqiAA1EwHPztwo4vUZNOR0LAsccMjkqztkhLMjhgQgwCsCspxnCBwQSJ','2024-11-27 07:52:15','2024-12-02 09:08:27'),(2,'Admin Editor','admin.editor@gmail.com',NULL,'$2y$12$EjuNZcP1Dscia86Ki1X4C.uEMGoZBhF.0On0O8JsSXtjX30t5yMZy',NULL,'2024-11-30 06:53:38','2024-12-04 03:36:34'),(7,'Admin Creator','admin.creator@gmail.com',NULL,'$2y$12$VyXpP.IBT5JUoZYRO3TAeuoJ21kXr6zx.qmyBCNNu2hto2XB8ZysO',NULL,'2024-12-03 05:09:11','2024-12-11 07:44:22');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `parent_id` bigint unsigned DEFAULT NULL,
  `created_id` bigint unsigned DEFAULT NULL,
  `updated_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`),
  KEY `categories_parent_id_foreign` (`parent_id`),
  KEY `categories_created_id_foreign` (`created_id`),
  KEY `categories_updated_id_foreign` (`updated_id`),
  CONSTRAINT `categories_created_id_foreign` FOREIGN KEY (`created_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_updated_id_foreign` FOREIGN KEY (`updated_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Main ','description main ',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(2,'Main 1','description main 1',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(3,'Main 2','description main 2',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(4,'Main 3','description main 3',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(5,'Main 4','description main 4',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(6,'Main 5','description main 5',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(7,'Main 6','description main 6',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(8,'Main 7','description main 7',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(9,'Main 8','description main 8',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(10,'Main 9','description main 9',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(11,'Main 10','description main 10',NULL,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(12,'Sub 1','description sub 1',1,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(13,'Sub 2','description sub 2',1,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(14,'Sub 3','description sub 3',2,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(15,'Sub 4','description sub 4',3,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(16,'Sub 5','description sub 5',4,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(17,'Sub 6','description sub 6',5,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(18,'Sub 7','description sub 7',6,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(19,'Sub 8','description sub 8',7,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(20,'Sub 9','description sub 9',8,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(21,'Sub 10','description sub 10',9,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(22,'Sub 11','description sub 11',10,1,NULL,'2024-12-19 08:06:46','2024-12-19 08:26:52'),(34,'Main 11','description main 11',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(35,'Main 12','description main 12',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(36,'Main 13','description main 13',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(37,'Main 14','description main 14',NULL,1,1,'2024-12-19 08:26:52','2024-12-21 07:04:30'),(38,'Main 15','description main 15',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(39,'Main 16','description main 16',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(40,'Main 17','description main 17',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(41,'Main 18','description main 18',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(42,'Main 19','description main 19',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(43,'Main 20','description main 20',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(44,'Main 21','description main 21',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(45,'Main 22','description main 22',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(46,'Main 23','description main 23',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(47,'Main 24','description main 24',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(48,'Main 25','description main 25',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(49,'Main 26','description main 26',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(50,'Main 27','description main 27',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(51,'Main 28','description main 28',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(52,'Main 29','description main 29',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(53,'Main 30','description main 30',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(54,'Main 31','description main 31',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(55,'Main 32','description main 32',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(56,'Main 33','description main 33',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(57,'Main 34','description main 34',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(58,'Main 35','description main 35',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(59,'Main 36','description main 36',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(60,'Main 37','description main 37',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(61,'Main 38','description main 38',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(62,'Main 39','description main 39',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(63,'Main 40','description main 40',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(64,'Main 41','description main 41',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(65,'Main 42','description main 42',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(66,'Main 43','description main 43',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(67,'Main 44','description main 44',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(68,'Main 45','description main 45',NULL,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(80,'Sub 12','description sub 12',1,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(81,'Sub 13','description sub 13',1,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(82,'Sub 14','description sub 14',2,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(83,'Sub 15','description sub 15',3,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(84,'Sub 16','description sub 16',4,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(85,'Sub 17','description sub 17',5,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(86,'Sub 18','description sub 18',6,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(87,'Sub 19','description sub 19',7,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(88,'Sub 20','description sub 20',8,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(89,'Sub 21','description sub 21',9,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(90,'Sub 22','description sub 22',10,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(91,'Sub 23','description sub 23',1,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(92,'Sub 24','description sub 24',1,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(93,'Sub 25','description sub 25',2,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(94,'Sub 26','description sub 26',3,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(95,'Sub 27','description sub 27',4,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(96,'Sub 28','description sub 28',5,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(97,'Sub 29','description sub 29',6,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52'),(98,'Sub 30','description sub 30',7,1,NULL,'2024-12-19 08:26:52','2024-12-19 08:26:52');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2024_11_27_074318_create_admins_table',2),(6,'2024_12_01_083946_create_permission_tables',3),(9,'2024_12_14_115721_create_categories_table',4),(10,'2024_12_21_100646_create_jobs_table',5),(13,'2024_12_21_111421_create_settings_table',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\Admin',1),(3,'App\\Models\\Admin',2),(2,'App\\Models\\Admin',7);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'role-list','admin','2024-12-02 10:09:14','2024-12-02 10:09:14'),(2,'role-create','admin','2024-12-02 10:09:14','2024-12-02 10:09:14'),(3,'role-edit','admin','2024-12-02 10:09:14','2024-12-02 10:09:14'),(4,'role-delete','admin','2024-12-02 10:09:14','2024-12-02 10:09:14'),(5,'product-list','web','2024-12-02 10:09:14','2024-12-02 10:09:14'),(6,'product-create','web','2024-12-02 10:09:14','2024-12-02 10:09:14'),(7,'product-edit','web','2024-12-02 10:09:14','2024-12-02 10:09:14'),(8,'product-delete','web','2024-12-02 10:09:14','2024-12-02 10:09:14');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (2,1),(3,1),(4,1),(1,2),(2,3),(3,3),(4,3),(1,20),(5,21),(6,21),(7,21),(8,21);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrator','admin','2024-12-02 10:39:37','2024-12-04 10:55:18'),(2,'Creator','admin','2024-12-02 10:50:00','2024-12-03 04:23:27'),(3,'Editor','admin','2024-12-03 03:56:54','2024-12-03 04:22:56'),(19,'No Permissions','admin','2024-12-03 05:17:30','2024-12-03 05:17:30'),(20,'User','admin','2024-12-04 10:50:46','2024-12-04 10:50:46'),(21,'Admin User','web','2024-12-05 04:08:10','2024-12-05 04:08:33');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `data_type` enum('string','integer','boolean','text','json','file') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'string',
  `type` tinyint NOT NULL DEFAULT '0',
  `created_id` bigint unsigned DEFAULT NULL,
  `updated_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`),
  KEY `settings_created_id_foreign` (`created_id`),
  KEY `settings_updated_id_foreign` (`updated_id`),
  CONSTRAINT `settings_created_id_foreign` FOREIGN KEY (`created_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `settings_updated_id_foreign` FOREIGN KEY (`updated_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'name','Inventory Management','string',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 06:21:21'),(2,'url','http://project-app.test/','string',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 06:21:21'),(3,'email','ahmedelasley@gmail.com','string',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 06:21:21'),(4,'timezone','Asia/Riyadh','string',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 14:01:54'),(5,'addresses','Egypt,KSA,UAE','json',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 14:01:54'),(6,'phones','0564421193, 01068382992, 05555555','json',0,1,NULL,'2024-12-21 06:20:04','2024-12-22 12:30:07'),(7,'pagination','15','integer',0,1,NULL,'2024-12-21 06:20:04','2024-12-22 12:13:34'),(8,'logo','assets/admin/img/uploads/YE4N08kzr1FYlL4YObmNeAp9jzclCWnAXZtH7JEM.svg','file',1,1,NULL,'2024-12-21 06:20:04','2024-12-22 10:59:09'),(9,'max_upload_size','25','integer',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 06:21:21'),(10,'default_language','en','string',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 06:21:21'),(11,'maintenance','0','boolean',0,1,NULL,'2024-12-21 06:20:04','2024-12-21 12:45:17'),(12,'favicon','assets/admin/img/uploads/SCVcsociaHsnJfgd9Ms8vXTBBWP1AfWFxUnFDgwB.png','file',1,1,NULL,'2024-12-21 07:26:33','2024-12-22 10:59:09');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'User','user@gmail.com',NULL,'$2y$12$1OOr/L53vNtW5jQcUOSAJ.8Y0e2GeXs2MoOU3RTTwgS4Nzl3uDOCS',NULL,'2024-11-27 04:04:24','2024-11-27 04:45:22'),(6,'User Create','usercreate@gmail.com',NULL,'$2y$12$MUmPWfSNqRyn1uMjC6sgF.kgckNbh7Kl416iES5HhBpOEQSG86AlW',NULL,'2024-12-01 08:10:49','2024-12-01 08:10:49'),(9,'sdsdsdds','admin@gmail.com',NULL,'$2y$12$SyKUYyD/bf8.l5g6.nwjgeJsFCIhLnJENzcd4666G2dmRMB74ecTi',NULL,'2024-12-01 10:11:02','2024-12-01 10:11:02'),(10,'sdvsdvfsdvsdv','adminds@gmail.com',NULL,'$2y$12$aiQuw6MA7tqLO7t2Cjm9H.ivM/L.1RxoF0TXp0xOfrKBY8ul.5cA2',NULL,'2024-12-01 10:11:26','2024-12-01 10:11:26'),(11,'fgjhdfjhdf','admfgin@gmail.com',NULL,'$2y$12$cA/OpXWPUkVIn9u0eYEuguir2trIq2p25zq8g0DafSXXe3PKtAjwa',NULL,'2024-12-01 10:27:18','2024-12-01 10:27:18'),(18,'asdfasdf','admiasdfasdfan@gmail.com','2024-12-02 07:41:35','$2y$12$K66hJOmqEi3wRDl9C9M8L.vdb/akolo4C54xs/gEVFpmwYOsNun0.',NULL,'2024-12-01 10:43:48','2024-12-02 07:41:35'),(19,'user7','user7@gmail.com','2024-12-02 07:41:08','$2y$12$NGF/YlJj.ngRz.HkebNDAuddANRlkk9kLMPLN946kdYqAgkuOWiv6',NULL,'2024-12-01 10:44:26','2024-12-02 07:41:08'),(20,'User Edit','useredit@gmail.com',NULL,'$2y$12$hnxEcxyMB/M9A15iOPrDD.rKrIzrczKl29KzKt4WGytxqXayYOsli',NULL,'2024-12-02 06:31:15','2024-12-02 07:46:11'),(21,'bbbbbb','bbbbbb@gmail.com','2024-12-02 09:03:23','$2y$12$MVj/Gg8g7Cule8pSmz/FM.v9OCCu4n.sgzaxbK.69abkftfOh.oJq',NULL,'2024-12-02 08:54:33','2024-12-02 09:03:23'),(22,'aaaaaa','aaaaaaaaaaaa@gmail.com',NULL,'$2y$12$ZxYw9iT4JCrxuHndjmdfAORFEpk1yDzQ1Ax.4riWC.MaR5ocpkWmO',NULL,'2024-12-02 09:36:08','2024-12-02 09:36:08'),(23,'fgsdsdfhsdhfsd','sdfhsdfhsdhf@gmail.com','2024-12-04 03:22:57','$2y$12$MtUxQd0Tq/AVMQ2GNgA5X.zscxykjYtOmtDydeGcYRPpdBNaZ2z3O',NULL,'2024-12-02 09:37:18','2024-12-04 03:22:57'),(24,'sadgfasdgadg','adasdfgasdgmin@gmail.com',NULL,'$2y$12$ZXEnc9a/5H0roJcqWeFPLu3bMG2mq8uqvzUFB.2b3HnXIrOBsIbgW',NULL,'2024-12-02 09:38:43','2024-12-02 09:38:43'),(25,'rtyetert','adertyertmin@gmail.com',NULL,'$2y$12$yjaYAekrE4EnCz44OhkLQ.UbZ4Rsvfwa8RBHEP1oDVp2uAp7mkBvW',NULL,'2024-12-02 09:39:04','2024-12-02 09:39:04'),(26,'Admsdafgasdgin','adasdgsdgmin@gmail.com',NULL,'$2y$12$jXWTu.mGSt0Chs2KeT2PuO5QgbeaRkyx8nJ6ZrpcPGhjtOB5lFnnC',NULL,'2024-12-03 04:07:22','2024-12-03 04:07:22'),(27,'Admsdafgasdgin','adasdgsdfdsggmin@gmail.com',NULL,'$2y$12$78S/edO0gZ1IOg3tm3jr5ePn1H2J2RaZXd5kok1/m8GbL3J.ZQGQ2',NULL,'2024-12-03 04:07:54','2024-12-03 04:07:54'),(28,'Userdghdfghdfghdfh','usedfghdfhfghgr@gmail.com',NULL,'$2y$12$GeLGzDR8n.HCAZcqwQOocujvkIG6k4RMo9viSgAKpcsF39AUyxn8a',NULL,'2024-12-03 04:08:05','2024-12-03 04:08:05'),(29,'Userdfffffffffffffffffffff','usffffffffffffffffffffffffer@gmail.com',NULL,'$2y$12$5vf0Xag87L7Rvkvf2d4LgObO1MK/Jd9G5vnTMuRmabT8ZzXbcVhQK',NULL,'2024-12-03 04:08:18','2024-12-03 04:08:18'),(30,'aaaaaaaa','aaaaaaaaaaaaan@gmail.com',NULL,'$2y$12$4CCLfETpDeMDdcwgpzZ1g./Krlmz5/t0Na44RlEXhjkoiiBUtctRu',NULL,'2024-12-12 04:17:20','2024-12-12 04:17:20'),(31,'assssssssss','asssssssssssssssssssss@gmail.com',NULL,'$2y$12$DXp3RjbbKaF23aL2r4pEg.eOlS.annA3nG7/bSKyfHGrhsxWaniIW',NULL,'2024-12-12 04:28:50','2024-12-12 04:28:50'),(32,'daaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','daaaaaaaaaaaaaaaaaaaaaaaa@gmail.com',NULL,'$2y$12$kaS6byjocxIj45XBJwfLweP41WCuvcgyi0RXb7UJQdlBKcMtPeC2u',NULL,'2024-12-12 04:29:19','2024-12-12 04:29:19');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

