<a href="{{ route('admin.dashboard') }}" class="app-brand-link">
  <span class="app-brand-logo demo">
    <img src="{{ URL::asset(getSetting('logo')) }}" width="200">
  </span>
</a>