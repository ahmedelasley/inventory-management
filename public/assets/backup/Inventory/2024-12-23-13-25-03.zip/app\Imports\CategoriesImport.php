<?php

namespace App\Imports;

use App\Models\Category;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithUpserts;

class CategoriesImport implements ToModel , WithUpserts
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Category([
            'name'=> $row[0],
            'description'=> $row[1],
            'parent_id'=> $row[2],
            'created_id'=> $row[3],
        ]);
    }

    public function uniqueBy()
    {
        return 'name';
    }
}
