@extends('admin.layouts.master')

@section('title', 'Categories')
@section('css')

@section('content')


      @livewire('categories.index')

@endsection
@section('js')
@endsection
