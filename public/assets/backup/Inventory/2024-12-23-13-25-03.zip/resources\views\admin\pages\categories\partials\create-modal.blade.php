

<button type="button" class="btn btn-primary btn-sm"
x-data=""
x-on:click.prevent="$dispatch('open-modal', 'confirm-user-create')"
>
    <span class="tf-icons bx bx-plus"></span>&nbsp; add
</button>
<x-modal wire:ignore.self name="confirm-user-create" :show="$errors->userDeletion->isNotEmpty()" focusable>
  <form method="post" action="{{route('admin.categories.store')}}" class="p-6">
    {{-- <form method="post" action="route('admin.categories.store')" class="p-6"> --}}
      @csrf
    {{-- @method('delete') --}}

    {{-- <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
        {{ __('Are you sure you want to delete your account?') }}
    </h2>

    <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
        {{ __('Once your account is deleted, all of its resources and data will be permanently deleted. Please enter your password to confirm you would like to permanently delete your account.') }}
    </p> --}}
    <div class="mb-3">
        <x-input-label for="name" class="form-label" :value="__('Name')" />
        <x-text-input id="name" name="name" type="text" class="form-control" :value="old('name')"  autofocus autocomplete="name" />
        <x-input-error class="mt-2" :messages="$errors->get('name')" />
    </div>

    <div class="mb-3">
        <x-input-label for="description" class="form-label" :value="__('Description')" />
        <x-text-input id="description" name="description" type="text" class="form-control" :value="old('description')" />
        <x-input-error class="mt-2" :messages="$errors->get('description')" />
    </div>
    <div class="mb-3">
      <label for="parent_id" class="form-label">Parent Category</label>
      <select name="parent_id" class="form-control" id="parent_id">
          <option value="">None</option>
          {{-- @forelse ($data as $cat)
            <option value="{{ $cat->id }}" {{ old('parent_id') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
          @empty
          @endforelse --}}
      </select>
      <x-input-error class="mt-2" :messages="$errors->get('parent_id')" />
    </div>

    <div class="mt-6 flex justify-end">
        <x-secondary-button x-on:click="$dispatch('close')">
            {{ __('Cancel') }}
        </x-secondary-button>
        <button type="submit"  class="btn btn-primary btn-sm ms-3">
            Create
            @if (session('status') === 'Created')
                <i
                    x-data="{ show: true }"
                    x-show="show"
                    x-transition
                    x-init="setTimeout(() => show = false, 2000)"
                    {{-- class="text-sm text-gray-600 dark:text-gray-400" --}}
                class='bx bx-loader-circle' ></i>
            @endif
        </button>

    </div>

    @if (session('status') === 'Created')
    <div
    class="bs-toast toast toast-placement-ex m-2"
    role="alert"
    aria-live="assertive"
    aria-atomic="true"
    data-delay="2000"
  >
    <div class="toast-header">
      <i class="bx bx-bell me-2"></i>
      <div class="me-auto fw-semibold">Bootstrap in</div>
      <small>11 mins ago</small>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body">Fruitcake chocolate bar tootsie roll gummies gummies jelly beans cake.</div>
  </div>
@endif
</form>
</x-modal>

@if (session('status') === 'Created')

<div
                class="bs-toast toast toast-placement-ex m-2"
                role="alert"
                aria-live="assertive"
                aria-atomic="true"
                data-delay="2000"
              >
                <div class="toast-header">
                  <i class="bx bx-bell me-2"></i>
                  <div class="me-auto fw-semibold">Bootstrap out</div>
                  <small>11 mins ago</small>
                  <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">Fruitcake chocolate bar tootsie roll gummies gummies jelly beans cake.</div>
              </div>
@endif