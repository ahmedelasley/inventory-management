

  <x-modal name="edit-{{$value->id}}" :show="$errors->userDeletion->isNotEmpty()" focusable>
      <form method="post" action="{{ route('admin.categories.update', $value) }}" class="p-6 text-start">
          @csrf
          @method('patch')
          <div class="mb-3">
            <x-input-label for="name" class="form-label" :value="__('Name')" />
            <x-text-input id="name" name="name" type="text" class="form-control" :value="old('name', $value->name)" required autofocus autocomplete="name" />
            <x-input-error class="mt-2" :messages="$errors->get('name')" />
        </div>
    
        <div class="mb-3">
            <x-input-label for="description" class="form-label" :value="__('Description')" />
            <x-text-input id="description" name="description" type="text" class="form-control" :value="old('description', $value->description)" />
            <x-input-error class="mt-2" :messages="$errors->get('description')" />
        </div>
        <div class="mb-3">
          <label for="parent_id" class="form-label">Parent Category</label>
          <select name="parent_id" class="form-control" id="parent_id">
              <option value="">None</option>
              {{-- @forelse ($data as $cat)
                @if ($cat->id != $value->id) <!-- Avoid selecting itself as parent -->
                    <option value="{{ $cat->id }}" {{ old('parent_id', $value->parent_id) == $cat->id ? 'selected' : '' }} @if ($value->parent_id == $cat->id) selected @endif>
                        {{ $cat->name }}
                    </option>
                @endif
              @empty
              @endforelse --}}
          </select>
          <x-input-error class="mt-2" :messages="$errors->get('parent_id')" />
        </div>

          <div class="mt-6 flex justify-end">
            <x-secondary-button x-on:click="$dispatch('close')">
                {{ __('Cancel') }}
            </x-secondary-button>
            <button type="submit"  class="btn btn-primary btn-sm ms-3">
                Update
                @if (session('status') === 'Updated')
                    <i
                        x-data="{ show: true }"
                        x-show="show"
                        x-transition
                        x-init="setTimeout(() => show = false, 2000)"
                        {{-- class="text-sm text-gray-600 dark:text-gray-400" --}}
                    class='bx bx-loader-circle' ></i>
                @endif
            </button>
          </div>
      </form>
  </x-modal>

