<?php

namespace App\Livewire\Admin\Settings;

use Livewire\Component;


class GetData extends Component
{

    public function render()
    {
        return view('admin.settings.get-data');
    }
}
