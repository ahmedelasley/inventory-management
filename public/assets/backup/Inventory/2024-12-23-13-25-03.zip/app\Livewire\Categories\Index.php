<?php

namespace App\Livewire\Categories;

use Livewire\Component;
use App\Livewire\Forms\CategoryForm;


use App\Models\Category;
use App\Http\Requests\CategoryRequest;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\DB;
use Livewire\WithPagination;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Illuminate\Support\Facades\Auth;


class Index extends Component
{
    use WithPagination, LivewireAlert;
    protected $paginationTheme = 'bootstrap';

    // public CategoryForm $form; 

    public $name;
    public $description;
    public $parent_id; 

    protected function rules(): array 
    {
        return (new CategoryRequest())->rules();
    } 

    public function updated($field)
    {
        $this->validateOnly($field);
    }

    public function closeForm()
    {
        //Reset 
        // $this->reset(); // Clear attributes
        $this->name = '';
        $this->description = '';
        $this->parent_id = ''; 
        $this->resetValidation();   // Clear Validation
        $this->resetErrorBag(); // Clear errors

        $this->dispatch('close-modal'); // Trigger modal close via JS
    }

    public function resetForm()
    {
        //Reset 
        $this->reset(); // Clear attributes
        $this->resetValidation();   // Clear Validation
        $this->resetErrorBag(); // Clear errors

        // $this->dispatch('close-modal'); // Trigger modal close via JS
    }
    public function save()
    {

        // dump($this->name);
        // dump($this->reset('name'));
        $this->validate();

         Category::create([
            'name' => $this->name,
            'description' => $this->description,
            'parent_id' => $this->parent_id,
            'created_id' => Auth::guard('admin')->user()->id,
        ]);

        //Reset 
        $this->reset(); // Clear attributes
        $this->resetValidation();   // Clear Validation
        $this->resetErrorBag(); // Clear errors

        $this->dispatch('close-modal'); // Trigger modal close via JS

        // Alert 
        $this->alert('success', __('Done Added Data Successfully'), [
            'position' => 'top-start',
            'timer' => 4000,
            'toast' => true,
            'timerProgressBar' => true,
        ]);
    }

    public function render()
    {
        $data = Category::with(['parent', 'children'])->paginate(20);
        return view('livewire.categories.index', [
            'data' => $data,
        ]);

    }
}
