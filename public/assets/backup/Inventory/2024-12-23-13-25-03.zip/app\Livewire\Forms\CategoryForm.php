<?php

namespace App\Livewire\Forms;

use App\Models\Category;
use Livewire\Form;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\CategoryRequest;

class CategoryForm extends Form
{
    public ?Category $category = null;

    public $name;
    public $description;
    public $parent_id; 
  
    protected function rules(): array 
    {
        return (new CategoryRequest())->rules();
    } 
 
    public function updated($field)
    {
        $this->validateOnly($field);
    }

    public function store(): void
    {

        // Check of Validation
        $validatedData       = $this->validate();
        dd($validatedData);

        // Query Create
        //  Category::create([
        //     'name' => $validatedData['name'],
        //     'description' => $validatedData['description'],
        //     'parent_id' => $validatedData['parent_id'],
        //     'created_id' => Auth::guard('admin')->user()->id,
        // ]);

        //Reset 
        // $this->resetValidation();
// $this->reset(); 
    }

    // public function rules(): array
    // {
    //     return [
    //         'name' => [
    //             'required',
    //             'string',
    //             'max:255',
    //             Rule::unique('categories', 'name')->ignore($this->category),
    //         ],
    //         'description' => [
    //             'required',
    //             'string',
    //         ],
    //         'parent_id' => [
    //             'nullable',
    //             'integer',
    //             Rule::exists('categories', 'id'),
    //         ],
    //     ];
    // }

    public function validationAttributes(): array
    {
        return [
            'name' => 'Name',
            'description' => 'Description',
            'parent_id' => 'Parent Category',
        ];
    }
}












// <?php

// namespace App\Livewire\Forms;

// use Livewire\Attributes\Validate;
// use Livewire\Form;
// use App\Models\Category;
// use App\Http\Requests\CategoryRequest;
// use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\DB;
// use RealRashid\SweetAlert\Facades\Alert;


// class CategoryForm extends Form
// {
//     public ?Category $category;

//     public $name; 
//     public $description; 
//     public $parent_id; 

//     protected function rules(): array 
//     {
//         return (new CategoryRequest())->rules();
//     } 

//     public function store() 
//     {
//         DB::beginTransaction();

//         try {

//             // Check of Validation
//             $validatedData       = $this->validate();

//             // Query Create
//             Category::create([
//                 'name' => $validatedData['name'],
//                 'description' => $validatedData['description'],
//                 'parent_id' => $validatedData['parent_id'],
//                 'created_id' => Auth::user()->id,
//             ]);

//             //Reset 
//             $this->resetValidation();
//             $this->reset(); 


//             DB::commit(); // All database operations are successful, commit the transaction
//             toast('Success Created Category!','success')->timerProgressBar();
            
//         } catch (Exception $e) {
//             DB::rollBack(); // Something went wrong, roll back the transaction
//             toast($e->getMessage(),'error')->timerProgressBar();
//         }
//     }


// }
