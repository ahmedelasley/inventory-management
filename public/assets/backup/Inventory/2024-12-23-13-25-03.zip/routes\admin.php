<?php

use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AdminRoleController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\UserRoleController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\SettingController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::prefix('admin')->name('admin.')->group(function () {

    Route::middleware('auth.admin')->group(function () {

        Route::get('/dashboard', function () {
            return view('admin.dashboard');
        })->name('dashboard');

        // Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        // Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        // Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

        Route::controller(ProfileController::class)->name('profile.')->group(function () {
            Route::get('/profile', 'edit')->name('edit');
            Route::patch('/profile', 'update')->name('update');
            Route::delete('/profile', 'destroy')->name('destroy');
        });

        Route::resources([
            '/admins' => AdminController::class,
            '/admins-roles' => AdminRoleController::class,
            '/users-roles' => UserRoleController::class,
            '/users' => UserController::class,
            '/categories' => CategoryController::class,
        ]);

        Route::controller(AdminController::class)->group(function () {
            Route::patch('/admins/verify/{admin}', 'verify')->name('admins.verify');
            Route::patch('/admins/assign-role/{admin}', 'assignRole')->name('admins.assign.role');

        });

        Route::controller(UserController::class)->group(function () {
            Route::patch('/users/verify/{user}', 'verify')->name('users.verify');
        });

        Route::get('/settings', [SettingController::class, 'index'])->name('settings');

        
    });

    require __DIR__.'/auth/admin.php';


});

