<!-- Modal -->
<div  wire:ignore.self  class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel1">Delete [ {{ $name }} ]</h5>
            <button type="button" class="btn-close" wire:click="closeForm" ></button>
        </div>
        <form method="post" wire:submit.prevent="submit">
            
        <div class="modal-body">

            <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
                {{ __('Are you sure you want to delete your Category?') }}
            </h2>
            <h5 class="">{{ $name }}</h5>
            <input id="name" wire:model="name" type="text" class="form-control" value="{{ $name }}"autofocus  />



        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline-secondary" wire:click="resetForm">
            Reset 
            </button>
            <button type="submit" class="btn btn-primary" wire:loading.attr="disabled"  wire:target="submit">Save
                <span wire:loading wire:target="submit" class="spinner-border spinner-border-sm text-white" role="status">
            </button>

        </div>
        </form>
        </div>
    </div>
</div>